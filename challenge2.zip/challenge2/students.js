let students = [
  { id: '1', name: 'Student1',sub1:"100",sub2:"90",sub3:"57",sub4:"57",sub5:"100", },
  { id: '2', name: 'Student2',sub1:"56",sub2:"89",sub3:"100",sub4:"88",sub5:"86", },
  { id: '3', name: 'Student4' ,sub1:"56",sub2:"100",sub3:"57",sub4:"100",sub5:"88",},
  { id: '4', name: 'Student5' ,sub1:"78",sub2:"100",sub3:"98",sub4:"88",sub5:"100",},
  { id: '5', name: 'Student3' ,sub1:"100",sub2:"56",sub3:"99",sub4:"100",sub5:"78",},
]

module.exports = students
